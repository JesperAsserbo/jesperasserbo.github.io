class Paper {
  constructor(insertPointX, insertPointY) {
    this.insertPoint = new p5.Vector(insertPointX, insertPointY);
    this.stepSize = 50;
  }

  DisplayPaperCross(width, height) {
    push();

    fill(255);
    noStroke();
    rect(this.insertPoint.x, this.insertPoint.y, width, height);

    stroke(0, 100, 250, 150);
    for (let i = 0; i < width / this.stepSize; i++) {
      line(
        this.insertPoint.x + this.stepSize * i,
        this.insertPoint.y,
        this.insertPoint.x + this.stepSize * i,
        this.insertPoint.y + height
      );
    }

    for (let i = 0; i < height / this.stepSize; i++) {
      line(
        this.insertPoint.x,
        this.insertPoint.y + this.stepSize * i,
        this.insertPoint.x + width,
        this.insertPoint.y + this.stepSize * i
      );
    }

    //*Marked line
    stroke(0, 100, 250, 200);
    strokeWeight(4);
    line(
      this.insertPoint.x + 250,
      this.insertPoint.y,
      this.insertPoint.x + 250,
      this.insertPoint.y + height
    );

    //*Holes
    noStroke();
    fill(100);
    circle(this.insertPoint.x + 100, this.insertPoint.y + 300, 50);
    circle(this.insertPoint.x + 100, this.insertPoint.y + 1100, 50);
    circle(this.insertPoint.x + 100, this.insertPoint.y + 1900, 50);
    circle(this.insertPoint.x + 100, this.insertPoint.y + 2700, 50);

    pop();
  }

  DisplayPaperBlank(width, height) {
    push();
    fill(255, 255, 255, 255);
    noStroke();
    rect(this.insertPoint.x, this.insertPoint.y, width, height);
    pop();
  }

  DisplayHeader() {
    push();
    textSize(100);
    textAlign(LEFT, BASELINE);
    textStyle(ITALIC);
    text("ShearSystem", 350, 150);

    textSize(50);
    text("Under development, ver. 1.3", 350, 250);

    textSize(50);
    text("12/10 - 2026", 1750, 150);
    pop();
  }

  DisplayText() {
    push();
    textSize(50);
    text("Input Data", this.insertPoint.x + 350, this.insertPoint.y + 392.5);
    text("Display", this.insertPoint.x + 750, this.insertPoint.y + 392.5);
    textAlign(CENTER);
    textSize(30);
    //text("ADD", this.insertPoint.x + 425, this.insertPoint.y + 440);
    //text("DELETE", this.insertPoint.x + 775, this.insertPoint.y + 440);
    //text("Output Data", this.insertPoint.x + 350, this.insertPoint.y + 1850);
    pop();
  }
}
